package com.example.shiftingmaze

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * The game is a WebView that loads assets/www/index.html.
 * AdMob lives here (native code); the HTML talks to it through window.AndroidAds.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())

    private var rewardedAd: RewardedAd? = null
    private var loading = false
    private var sdkReady = false
    private var retry = 0
    @Volatile private var adReady = false      // read from the JS thread

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // the game saves progress in localStorage
            mediaPlaybackRequiresUserGesture = false
            allowContentAccess = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https") {   // never navigate the game away
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        }
        web.addJavascriptInterface(AdsBridge(), "AndroidAds")
        web.loadUrl("file:///android_asset/www/index.html")

        // Initialise the Mobile Ads SDK off the main thread, then start loading the first ad.
        Thread {
            MobileAds.initialize(this) {
                main.post { sdkReady = true; loadAd() }
            }
        }.start()
    }

    // ---------------- AdMob ----------------

    private fun loadAd() {
        if (!sdkReady || loading || rewardedAd != null) return
        loading = true
        RewardedAd.load(
            this,
            BuildConfig.REWARDED_AD_UNIT_ID,   // debug = Google test unit, release = your real unit
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad; adReady = true; loading = false; retry = 0
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null; adReady = false; loading = false
                    retry++
                    val delay = minOf(60_000L, 2_000L shl minOf(retry, 5))   // back off, no hammering
                    main.postDelayed({ loadAd() }, delay)
                }
            }
        )
    }

    private fun showAd(requestId: String) {
        val ad = rewardedAd
        if (ad == null || !ID_RE.matches(requestId)) {
            deliver(requestId, "failed"); loadAd(); return
        }
        rewardedAd = null; adReady = false
        var earned = false
        var done = false
        fun finish(status: String) {
            if (done) return            // exactly one result per ad
            done = true
            deliver(requestId, status)
            loadAd()
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { finish(if (earned) "rewarded" else "closed") }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { finish("failed") }
        }
        // Fires only when the user actually completed the ad
        ad.show(this) { earned = true }
    }

    private fun deliver(requestId: String, status: String) {
        if (!ID_RE.matches(requestId)) return
        web.evaluateJavascript("window.onRewardedResult&&window.onRewardedResult('$requestId','$status')", null)
    }

    /** What the HTML can call (runs on a background thread, so hop to the UI thread). */
    private inner class AdsBridge {
        @JavascriptInterface fun isReady(): Boolean = adReady
        @JavascriptInterface fun preload() { runOnUiThread { loadAd() } }
        @JavascriptInterface fun showRewarded(requestId: String) { runOnUiThread { showAd(requestId) } }
    }

    // ---------------- lifecycle ----------------

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        web.removeJavascriptInterface("AndroidAds")
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private val ID_RE = Regex("^[A-Za-z0-9_]{1,64}$")
    }
}
